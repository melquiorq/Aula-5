# -*- coding: utf-8 -*-
# -----------------------------------------------------------------------------
# Copyright (c) Spyder Project Contributors
#
# Licensed under the terms of the MIT License
# -----------------------------------------------------------------------------

"""Spyder Notebook plugin."""

# Local imports
from spyder_notebook.notebookplugin import NotebookPlugin as PLUGIN_CLASS
from spyder_notebook._version import __version__

PLUGIN_CLASS
