# -*- coding: utf-8 -*-
#
# Copyright (c) Jupyter Development Team, Spyder Project Contributors.
# Distributed under the terms of the Modified BSD License.

"""Notebook server for the Spyder notebook plugin."""
